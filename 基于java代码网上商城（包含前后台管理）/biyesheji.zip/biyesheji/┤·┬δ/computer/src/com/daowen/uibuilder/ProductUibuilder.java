package com.daowen.uibuilder;
public class ProductUibuilder extends UibuilderBase {
	public  ProductUibuilder(String lanmuclassname){
		super("product", lanmuclassname, "title", "tupian");
	}
}
