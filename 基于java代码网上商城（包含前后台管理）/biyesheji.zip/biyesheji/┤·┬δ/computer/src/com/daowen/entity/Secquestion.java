﻿package com.daowen.entity;
import java.util.Date;
import javax.persistence.*;
@Entity
public class Secquestion
{
@Id
@GeneratedValue(strategy =GenerationType.AUTO)
   private int id ;
   public int getId() 
   {
      return id;
  }
   public void setId(int id) 
   {
      this.id= id;
  }
   private String title ;
   public String getTitle() 
   {
      return title;
  }
   public void setTitle(String title) 
   {
      this.title= title;
  }
   private String answer ;
   public String getAnswer() 
   {
      return answer;
  }
   public void setAnswer(String answer) 
   {
      this.answer= answer;
  }
   private String accountname ;
   public String getAccountname() 
   {
      return accountname;
  }
   public void setAccountname(String accountname) 
   {
      this.accountname= accountname;
  }
}
