package com.daowen.util;

public class Total {
	private long results;

	public long getResults() {
		return results;
	}

	public void setResults(long results) {
		this.results = results;
	}
}
