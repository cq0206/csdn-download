package com.daowen.util;

import java.util.List;

public class TotalJson {
	private long results;
	private List items;
	public List getItems() {
		return items;
	}

	public void setItems(List items) {
		this.items = items;
	}

	public long getResults() {
		return results;
	}

	public void setResults(long results) {
		this.results = results;
	}
}
