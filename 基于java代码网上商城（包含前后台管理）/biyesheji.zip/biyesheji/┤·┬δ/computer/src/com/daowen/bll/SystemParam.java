package com.daowen.bll;

public class SystemParam {

	
	private static String  siteroot="/computer";
	
	public static  String getSiteRoot(){
		
		
		return siteroot;
	}
	
	public static String  getContext(){
		
		return "computer";
	}
	
	
	
}
