package com.book.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.model.Shopcar;
import com.book.util.JdbcDB;

public class ShopcarService {

	// /////////////����Ʒ���빺�ﳵ//////////////
	public static void add(Shopcar shop) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "insert into shopcar(userid,productid,qty) values("
				+ shop.getUserid() + "," + shop.getProductid() + ","
				+ shop.getQty() + ")";
		int i = st.executeUpdate(sql);
		JdbcDB.CloseConnection(conn);
	}

	// ///////////////�ж���Ʒ�Ƿ��Ѿ����õ����ﳵ////////////
	public static boolean getproductExists(Shopcar shop) throws SQLException {
		boolean result = false;
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from shopcar" + " where userid="
				+ shop.getUserid() + " and productid = " + shop.getProductid();
		ResultSet rs = st.executeQuery(sql);
		if (rs.next()) {
			result = true;
		}
		JdbcDB.CloseConnection(conn);
		return result;
	}

	// ///////////////��ȡ���ﳵ��Ϣ////////////
	public static List<Shopcar> getaAllShopcar(Shopcar shop)
			throws SQLException {
		List<Shopcar> list = new ArrayList<Shopcar>();
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select userid,shopcar.productid,qty,name,price"
				+ " from shopcar,product"
				+ " where shopcar.productid = product.productid"
				+ " and userid=" + shop.getUserid();
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			Shopcar s = new Shopcar();
			s.setUserid(rs.getInt("userid"));
			s.setProductid(rs.getInt("productid"));
			s.setName(rs.getString("name"));
			s.setPrice(rs.getDouble("price"));
			s.setQty(rs.getInt("qty"));
			list.add(s);
		}
		JdbcDB.CloseConnection(conn);
		return list;
	}

	// /////////ͨ���û�id�õ����ﳵ//////////////
	public static Shopcar getaShopcarById(Shopcar shop) throws SQLException {
		Shopcar s = null;
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select userid,shopcar.productid,qty,name,price"
				+ " from shopcar,product"
				+ " where shopcar.productid = product.productid"
				+ " and userid=" + shop.getUserid() + " and shopcar.productid="
				+ shop.getProductid();
		ResultSet rs = st.executeQuery(sql);
		if (rs.next()) {
			s = new Shopcar();
			s.setUserid(rs.getInt("userid"));
			s.setProductid(rs.getInt("productid"));
			s.setName(rs.getString("name"));
			s.setPrice(rs.getDouble("price"));
			s.setQty(rs.getInt("qty"));
		}
		JdbcDB.CloseConnection(conn);
		return s;
	}

	// /////////////��չ��ﳵ///////////////
	public static void clear(int userid) {
		Connection conn = null;
		try {
			conn = JdbcDB.getConnection();
			String sql = "delete shopcar where userid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userid);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// ///////////////�޸Ĺ��ﳵ��Ʒ����///////////////////
	// flag = 0 ��ʾ��Ʒ�ظ����õ����ﳵ��������1
	// flag = 1 ��ʾ�ڹ��ﳵ����ҳ���У��ֹ��޸���Ʒ����
	public static void update(Shopcar shop, int flag) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "";
		if (flag == 0) {
			sql = "update shopcar set qty=qty+1" + " where userid="
					+ shop.getUserid() + " and productid = "
					+ shop.getProductid();
		} else if (flag == 1) {
			sql = "update shopcar set qty=" + shop.getQty() + " where userid="
					+ shop.getUserid() + " and productid = "
					+ shop.getProductid();
		}
		int i = st.executeUpdate(sql);
		JdbcDB.CloseConnection(conn);
	}

	// /////////////�h�����ﳵ/////////////
	public static void delete(Shopcar shop) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "delete shopcar " + " where userid=" + shop.getUserid()
				+ " and productid = " + shop.getProductid();
		int i = st.executeUpdate(sql);
		JdbcDB.CloseConnection(conn);

	}

}
