package com.book.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.model.*;
import com.book.util.*;

public class OrderService {
	public static void order(int userid) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "{ call proc_order(?) }";
		CallableStatement cs = conn.prepareCall(sql);
		cs.setInt(1, userid);
		cs.executeUpdate();
		JdbcDB.CloseConnection(conn);

	}

	// ////////////////////////////////////////����û������еĶ���
	public static List<Order> getAllOrder() throws SQLException {
		List<Order> list = new ArrayList<Order>();
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from orders";
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			Order s = new Order();
			s.setOrderid(rs.getInt("orderid"));
			s.setUserid(rs.getInt("userid"));
			s.setOrderdate(rs.getDate("orderdate"));
			s.setName(rs.getString("name"));
			s.setAddress(rs.getString("address"));
			s.setPhone(rs.getString("phone"));
			list.add(s);
		}
		JdbcDB.CloseConnection(conn);
		return list;
	}

	// /////////////////////////////////////ͨ���û���id�õ���Ӧ�Ķ���
	public static List<Order> getOrderByUserId(int userid) throws SQLException {
		List<Order> list = new ArrayList<Order>();
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from orders" + " where userid=" + userid;
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			Order s = new Order();
			s.setOrderid(rs.getInt("orderid"));
			s.setUserid(rs.getInt("userid"));
			s.setOrderdate(rs.getDate("orderdate"));
			s.setName(rs.getString("name"));
			s.setAddress(rs.getString("address"));
			s.setPhone(rs.getString("phone"));
			list.add(s);
		}
		JdbcDB.CloseConnection(conn);

		return list;
	}

	// //////////////////////////////////////////ɾ���û�����
	public static void delete(int orderid) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "delete orders where orderid=" + orderid;
		int i = st.executeUpdate(sql);
		JdbcDB.CloseConnection(conn);
	}

	// //////////////////////////////////////////ͨ��������id�õ���Ӧ�ö���
	public static Order getOrderByOrderId(int orderid) throws SQLException {
		Order s = new Order();
		Connection conn = JdbcDB.getConnection();
		// ����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from orders" + " where userid=" + orderid;
		ResultSet rs = st.executeQuery(sql);
		if (rs.next()) {
			s.setOrderid(rs.getInt("orderid"));
			s.setUserid(rs.getInt("userid"));
			s.setOrderdate(rs.getDate("orderdate"));
			s.setName(rs.getString("name"));
			s.setAddress(rs.getString("address"));
			s.setPhone(rs.getString("phone"));
			JdbcDB.CloseConnection(conn);
		}

		return s;
	}

}
