package com.book.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.model.Product;
import com.book.util.JdbcDB;

public class ProductService {

	//////////////////////////////////////////������Ʒ	 
	public static void add(Product product) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "insert into product(code,name,beforeprice,price,mark,pic,typeid) "+"values('"
			        + product.getCode() + "','" 
			        + product.getName() + "','"
			        + product.getBeforeprice()+ "','"
			        + product.getPrice() + "','"
			        + product.getMark() + "','"
			        + product.getPic() + "','" 
			        + product.getTypeid() +"')";
			        
		int i = st.executeUpdate(sql);
		JdbcDB.CloseConnection(conn);

	}
	
	
   //////////////////////////////////////////�޸���Ʒ��Ϣ
	public static void update(Product product) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "update product set name='" + product.getName() 
		        + "',code='" + product.getCode()
		        + "',beforeprice=" + product.getBeforeprice()
		        + "',price=" + product.getPrice()		         
		        + ",mark='" + product.getMark()
		        + "',pic='" + product.getPic()
		        + "',typeid='" + product.getTypeid()
		        + "where productid=" + product.getProductid();
	
		int i = st.executeUpdate(sql);
   
		JdbcDB.CloseConnection(conn);

	}
	
	
   ////////////////////////////////////////////ɾ����Ʒ
	public static void delete(int productid) throws SQLException {

		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "delete product where productid=" + productid;
		int i = st.executeUpdate(sql);
		JdbcDB.CloseConnection(conn);
	}

	
    //////////////////////////////////////////��ѯ������Ʒ��Ϣ
	public static List<Product> getProductByTypeid(int typeid) throws SQLException {
		List<Product> list = new ArrayList<Product>();
		
		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from product where typeid=" +  typeid;
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			 Product t = new Product();
			 t.setProductid(rs.getInt("productid"));
			 t.setCode(rs.getString("code"));
			 t.setName(rs.getString("name"));
			 t.setPrice(rs.getDouble("price"));
         	 t.setMark(rs.getString("mark"));
			 t.setPic(rs.getString("pic"));
			 t.setTypeid(rs.getInt("typeid"));
			 t.setBeforeprice(rs.getDouble("beforeprice"));
		     list.add(t);		
		}

		JdbcDB.CloseConnection(conn);
		return list;
	}
	
	
	
   ////////////////////////////////////////// //����ID��ѯ��Ʒ
	public static Product getProductById(int productid) throws SQLException {
		Product product = null;
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from product where productid=" +  productid;	
		ResultSet rs = st.executeQuery(sql);

		if (rs.next()) {
			product = new Product();
			product.setProductid(rs.getInt("productid"));
			product.setCode(rs.getString("code"));
			product.setName(rs.getString("name"));
			product.setPrice(rs.getDouble("price"));
			product.setMark(rs.getString("mark"));
			product.setPic(rs.getString("pic"));	
			product.setTypeid(rs.getInt("typeid"));
			product.setBeforeprice(rs.getDouble("beforeprice"));
		     	
		}

		JdbcDB.CloseConnection(conn);
		
		return product;
	}
	
	
   ////////////////////////////////////////////��ѯ������Ʒ��Ϣ
	public static List<Product> getAllProduct() throws SQLException {
		List<Product> list = new ArrayList<Product>();
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from product";		
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			 Product t = new Product();
			 t.setProductid(rs.getInt("productid"));
			 t.setCode(rs.getString("code"));
			 t.setName(rs.getString("name"));
			 t.setPrice(rs.getDouble("price"));
			 t.setMark(rs.getString("mark"));
			 t.setPic(rs.getString("pic"));
			 t.setTypeid(rs.getInt("typeid"));
			 t.setBeforeprice(rs.getDouble("beforeprice"));
			 
		     list.add(t);		
		}
		JdbcDB.CloseConnection(conn);		
		return list;
	}
	
}


