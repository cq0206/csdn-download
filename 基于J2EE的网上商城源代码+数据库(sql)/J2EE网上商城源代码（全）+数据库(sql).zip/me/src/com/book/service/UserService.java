package com.book.service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// import com.book.model.Product;
import com.book.model.User;
import com.book.service.*;
import com.book.util.JdbcDB;

public class UserService {

	//�û���¼	 
	public static boolean userLogin(User user) throws SQLException {
		boolean result = false;
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from users where username=? and userpwd=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,user.getUsername());
		ps.setString(2,user.getUserpwd());		
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			result = true;
		}

		JdbcDB.CloseConnection(conn);
		return result;

	}

	//�û�ע�� 
	public static boolean add(User user) throws SQLException {
		boolean result = false;
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "insert into users(username,userpwd,reuserpwd,name,jiguan,email,phone,address) values('" 
			    + user.getUsername() + "','"
			    + user.getUserpwd() + "','"
			    + user.getReuserpwd()+"','"
			    + user.getName()+"','"
			    + user.getJiguan()+"','"
			    + user.getEmail()+"','"
			    + user.getPhone()+"','"
			    + user.getAddress()+"')";
		
		 int i = st.executeUpdate(sql);
		if (i!=0) {
			result = true;
		}
		JdbcDB.CloseConnection(conn);
		return result;
	}

	//��ѯ�����û���Ϣ
	public static List<User> getAllUser() throws SQLException {
		List<User> list = new ArrayList<User>();		
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from users";
		ResultSet rs = st.executeQuery(sql);

		while (rs.next()) {
			 User user = new User();		  
		     user.setUserid(rs.getInt("userid"));		     
		     user.setUsername(rs.getString("username"));
		     user.setUserpwd(rs.getString("userpwd"));
		     user.setReuserpwd(rs.getString("reuserpwd"));
		     user.setName(rs.getString("name"));
		     user.setPhone(rs.getString("phone"));
		     user.setAddress(rs.getString("address"));
		     user.setJiguan(rs.getString("jiguan"));
		     user.setEmail(rs.getString("email"));
		     
		     list.add(user);		
		}
		JdbcDB.CloseConnection(conn);		
		return list;
	}

	
	
	public static User getUserById(int userid) throws SQLException {
		 User user = null;
		
		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from users where userid="+userid;
		ResultSet rs = st.executeQuery(sql);

		if (rs.next()) {
			 user = new User();
			 user.setUserid(rs.getInt("userid"));
		     
		     user.setUsername(rs.getString("username"));
		     user.setUserpwd(rs.getString("userpwd"));
		     user.setReuserpwd(rs.getString("reuserpwd"));
		     user.setName(rs.getString("name"));
		     user.setPhone(rs.getString("phone"));
		     user.setAddress(rs.getString("address"));
		     user.setJiguan(rs.getString("jiguan")); 
		     user.setEmail(rs.getString("email"));
		     
		}

		JdbcDB.CloseConnection(conn);
		
		return user;
	}

	
	
	
	
	
	
	//�����û�����ѯ���û����
	public static int getUserID(String username) throws SQLException {
        int id=0; 		
		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select userid from users where username='" + username + "'";
		ResultSet rs = st.executeQuery(sql);
		if(rs.next()) {
			id = rs.getInt("userid");
		}
		JdbcDB.CloseConnection(conn);		
		return id;
	}

	 ////////////////////////////////////////////ɾ���û�
	public static void delete(int userid) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "delete users where userid=" + userid;
		int i = st.executeUpdate(sql);
		JdbcDB.CloseConnection(conn);
	}
	
	//�û���Ϣ�޸�	
	public static void update(User user) throws SQLException {
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "update users set username='" + user.getUsername()
		        + "',userpwd='" + user.getUserpwd()
		        + "',reuserpwd='" + user.getReuserpwd()	         
		        + "',name='" + user.getName()
		        + "',phone='" + user.getPhone()
		        + "',address='" + user.getAddress()
		        + "',jiguan='" + user.getJiguan()
		        + "',email=" + user.getEmail()
		        + "where userid=" + user.getUserid();
	
		int i = st.executeUpdate(sql);
   
		JdbcDB.CloseConnection(conn);

	}
	
	//�û���������
	public static boolean RePassword(User user) {
		return true;
	}
	
}
