package com.book.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.book.model.OrderDetail;
import com.book.model.Shopcar;
import com.book.util.JdbcDB;
//��ѯ������ϸ��Ϣ
public class OrderDetailService {
   public static List<OrderDetail> getOrderDetailById(int orderid) throws SQLException{
	   List<OrderDetail> list = new ArrayList<OrderDetail>();	   
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();		
		String sql = "select orderid,orderdetails.productid,qty,product.name,product.price"
			    + " from orderdetails,product"
			    + " where orderdetails.productid = product.productid"
				+ " and orderid=" + orderid;
		ResultSet rs = st.executeQuery(sql);
		while(rs.next()){
			OrderDetail s = new OrderDetail();
			s.setOrderid(rs.getInt("orderid"));
			s.setProductid(rs.getInt("productid"));
			s.setName(rs.getString("name"));
			s.setPrice(rs.getDouble("price"));
			s.setQty(rs.getInt("qty"));
			list.add(s);		
			}
		
		JdbcDB.CloseConnection(conn);	   	   
	   return list;
   }
}
