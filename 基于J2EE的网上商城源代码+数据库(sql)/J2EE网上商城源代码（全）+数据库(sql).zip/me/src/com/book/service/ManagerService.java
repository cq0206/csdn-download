package com.book.service;

import java.sql.*;
// import com.book.model.Product;
import com.book.model.*;
import com.book.util.JdbcDB;

public class ManagerService {

	//�û���¼	 
	public static boolean managerLogin(Manager manager) throws SQLException {
		boolean result = false;
		Connection conn = JdbcDB.getConnection();
		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from Manager where Mname=? and Mpwd=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,manager.getMname());
		ps.setString(2,manager.getMpwd());		
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			result = true;
		}

		JdbcDB.CloseConnection(conn);
		return result;

	}
	//�����û�����ѯ���û����
	public static int getMid(String Mname) throws SQLException {
        int id=0; 		
		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select Mid from Manager where Mname='" + Mname + "'";
		ResultSet rs = st.executeQuery(sql);
		if(rs.next()) {
			id = rs.getInt("Mid");
		}
		JdbcDB.CloseConnection(conn);		
		return id;
	}
}