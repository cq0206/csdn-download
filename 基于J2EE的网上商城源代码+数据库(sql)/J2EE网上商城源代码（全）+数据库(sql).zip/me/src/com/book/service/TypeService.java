package com.book.service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.book.model.Type;
import com.book.model.User;
import com.book.service.*;
import com.book.util.JdbcDB;

public class TypeService {

	//��������	 
	public static void add(Type type) throws SQLException {

		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "insert into type(typename,typedesc) values('"+ type.getTypename() + "','" + type.getTypedesc()+ "')";

		int i = st.executeUpdate(sql);

		JdbcDB.CloseConnection(conn);

	}

	public static void update(Type type) throws SQLException {

		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "update type set typename='"
				+ type.getTypename() + "',typedesc='" + type.getTypedesc()
				+ "' where typeid=" + type.getTypeid();

		int i = st.executeUpdate(sql);

		JdbcDB.CloseConnection(conn);

	}

	public static void delete(int typeid) throws SQLException {

		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "delete type where typeid=" + typeid;
		int i = st.executeUpdate(sql);

		JdbcDB.CloseConnection(conn);
	}

	
	//��ѯ������Ʒ������Ϣ
	public static List getAllType() throws SQLException {
		List<Type> list = new ArrayList<Type>();
		
		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from type";
		ResultSet rs = st.executeQuery(sql);

		while (rs.next()) {
			 Type t = new Type();
		     t.setTypeid(rs.getInt("typeid"));
		     t.setTypename(rs.getString("typename"));
		     t.setTypedesc(rs.getString("typedesc"));
		     list.add(t);		
		}

		JdbcDB.CloseConnection(conn);
		
		return list;
	}

	//��ѯ������Ʒ������Ϣ
	public static Type getType(int typeid) throws SQLException {
		Type t = null;
		
		Connection conn = JdbcDB.getConnection();

		//����ִ��SQL�����(Statement)
		Statement st = conn.createStatement();
		String sql = "select * from type where typeid=" + typeid;
		ResultSet rs = st.executeQuery(sql);

		if (rs.next()) {
			 t = new Type();
		     t.setTypeid(rs.getInt("typeid"));
		     t.setTypename(rs.getString("typename"));
		     t.setTypedesc(rs.getString("typedesc"));
		}

		JdbcDB.CloseConnection(conn);
		
		return t;
	}
	
}

