package com.book.model;

public class Manager {
	private int Mid;
	private String Mname;
	private String Mpwd;
	private String RMpwd;
	
	public int getMid() {
		return Mid;
	}
	public void setMid(int mid) {
		Mid = mid;
	}
	public String getMname() {
		return Mname;
	}
	public void setMname(String mname) {
		Mname = mname;
	}
	public String getMpwd() {
		return Mpwd;
	}
	public void setMpwd(String mpwd) {
		Mpwd = mpwd;
	}
	public String getRMpwd() {
		return RMpwd;
	}
	public void setRMpwd(String rMpwd) {
		RMpwd = rMpwd;
	}
	
	
	
	
}
