﻿/// <reference path="jquery-1.3.2.min-vsdoc.js" />
$(function () {
    //限时抢购
    $("#justTime .Jmenu li").click(function () {
        var index = $("#justTime").attr('index');
        if (!index) {
            index = 0;
            $("#justTime").attr('index', 0);
        } else {
            index = parseInt(index);
        }
        if ($("a", this).hasClass('prev_s')) {
            index--;
        } else {
            index++;
        }
        if (index >= $("#justTime .tab-holder").length)
            index = 0;
        if (index < 0)
            index = $("#justTime .tab-holder").length - 1;
        $("#justTime").attr('index', index);
        $("#justTime .tab-holder:visible").hide();
        $("#justTime .tab-holder").eq(index).show();
        return false;
    });

    $("#justTime .tab-holder").each(function (index, item) {
        try {
            var op = parseFloat($(".v0", item).val());
            var pr = parseFloat($(".v1", item).val());
            var off = Math.round(pr / op * 100) * 0.1;
            $(".zhekou-img", item).html((off + ".0").substr(0, 3));
        } catch (ex) { $(".zhekou-img", item).remove(); }
    });

    if ($("#justTime .tab-holder").length > 0) {
        setInterval(function () {
            $("#justTime .tab-holder").each(function (index, item) {
                var endDate = new Date($(".endDate", item).val().replace(/-/g, "/"));
                var timeSpan = endDate - new Date();
                if (timeSpan < 0) {
                    var container = ".time-holder .title" + (index + 1);
                    $(container).html("<span class='f-14bold f-red'>此次限时抢购已结束!</span>");
                    return true;
                }
                var h = parseInt((timeSpan / 1000 / 60 / 60));
                var m = parseInt((timeSpan - h * 1000 * 60 * 60) / 1000 / 60);
                var s = parseInt((timeSpan - h * 1000 * 60 * 60 - m * 1000 * 60) / 1000);
                $(".h", item).text(h > 9 || h < 0 ? Math.abs(h) : ("0" + h));
                $(".m", item).text(m > 9 || m < 0 ? Math.abs(m) : ("0" + m));
                $(".s", item).text(s > 9 || s < 0 ? Math.abs(s) : ("0" + s));
            });
        }, 1000);
    }
    //TAB
    $(".Jtab").each(function () {
        var tab = this;
        $(".Jmenu li", tab).each(function (index, item) {
            $(item).hover(function () {
                $(".current", tab).removeClass("current");
                $(this).addClass("current");
                $(".Jmenudiv>*", tab).hide();
                $(".Jmenudiv", tab).children().eq(index).show();
            });
        });
    });
    //搜索
    $(".search-textA#q").focus(function () {
        if ($(this).val() == $(this).attr('oldv'))
            $(this).val('');
        $(this).css('color', '#333');
    }).blur(function () {
        if ($(this).val() == '')
            $(this).val($(this).attr('oldv'));
        if ($(this).val() == $(this).attr('oldv'))
            $(this).css('color', '#ccc');
    });
    $("form#search").submit(function () {
        if ($(".search-textA#q").val().trim() == '' || $(".search-textA#q").val() == $(".search-textA#q").attr('oldv')) {
            alert('请输入关键字');
            return false;
        }
    });

    ///搜索头部处理
    var url = window.location.href;
    if (url.indexOf("ns.99read.com") > 0) {
        var text = $(".search-textA#q");
        if ($(text).val() === '搜索商品...') {
            $(text).val('');
        }
    }


    //分类导航
    var isloaded = false;
    var getCategoryItem = function (name) {
        if (!categories) return null;
        for (var i = 0; i < categories.length; i++) {
            var cateItem = categories[i];
            if (cateItem.n == name) return cateItem;
        }
        return null;
    }
    var loadCategories = function () {
        if (!isloaded) {
            isloaded = true;
            var $items = $("ul.Jmenu-list").children("li");
            $.get("/Ajax/GetCategories.aspx", {}, function (result) {
                $(result).filter("div").each(function (i, item) {
                    var $item = $items.eq(i);
                    if ($(".indexpage2010_popup", $item).size() == 0) {
                        $item.prepend(item);
                        $(".indexpage2010_popup", $item).hover(function () {
                            $(".Jmenu-list h2 .current").removeClass("current");
                            $("h2 a", $(this).parent()).addClass("current");
                        }, function () {
                            $(".Jmenu-list .current").removeClass("current");
                        })
                    }
                });
            }, "html");
        }
    }
    var loadCategory = function ($li) {
        if ($li.children(".indexpage2010_popup").size() == 0) {
            var $item = $li.children("h2").find(".Jlabel");
            var cate = getCategoryItem($.trim($item.text()));
            if (!cate) return;
            var $popup = $("<div class='indexpage2010_popup Jindex-002'></div>").prependTo($li);

            var $popup_left = $("<div class='indexpage2010_popup_left'></div>").prependTo($popup).append("<h4 class='f-hui f-bold'>选择分类</h4>");
            for (var i = 0; i < cate.c.length; i++) {
                var chi = cate.c[i];
                var $item = $("<div class='indexpage2010_list'></div>").appendTo($popup_left);
                var $item_h = $("<h3></h3>").appendTo($item);
                if (chi.u) $("<a class='f-title-A f-bold'></a>").attr("href", "http://www.99read.com" + chi.u).attr("target", "_blank").appendTo($item_h).text(chi.n);
                else $item_h.text(chi.n);
                $item_c = $("<div class='indexpage2010_link'></div>").appendTo($item);
                for (var j = 0; j < chi.c.length; j++) {
                    var chiItem = chi.c[j];
                    $("<a></a>").attr("target", "_blank").attr("href", "http://search.99read.com" + chiItem.u).appendTo($item_c).text(chiItem.n);
                }
            }

            var $popup_right = $("<div></div>").prependTo($popup).addClass("indexpage2010_popup_right").append("<h3 class='f-hui f-bold'>主题馆</h3>");
            var $popup_right_subjects = $("<div></div>").addClass("indexpage2010_link-TuiJian").appendTo($popup_right);
            for (var i = 0; i < cate.s.length; i++) {
                var sub = cate.s[i];
                $("<a></a>").appendTo($popup_right_subjects).attr("href", "http://www.99read.com/" + sub.u).attr("target", "_blank").text(sub.n);
            }
        }
        $li.show();

    }
    if ($(".Jtab-newhead:hidden").length > 0) {
        $(".allsort").hover(function () {
            //loadCategories();
            window.openMenu = setTimeout(function () { $(".Jtab-newhead").show() }, 300);
        }, function () { clearTimeout(openMenu); $(".indexpage2010_popup:visible").hide(); $(".Jtab-newhead").hide(); });
    }
    $(".Jindex-001").each(function (index, item) {
        $(this).removeClass("Jindex-001")
        $(this).addClass("Jindex-0" + (index + 1 > 9 ? "" : "0") + (index + 1));
    });
    $(".Jmenu-list>li").hover(function (e) {
        var $sender = $(this);
        loadCategory($sender);
        clearTimeout(window.hideMenu);
        if ($(".indexpage2010_popup:visible").length > 0 && e.pageX > $(".indexpage2010_popup:visible").offset().left) {
            return false;
        }
        $(".indexpage2010_popup:visible").hide();
        $(".indexpage2010_popup", $sender).show();
        //        $(".indexpage2010_popup", this).show();
        //        if ($(".indexpage2010_popup", $sender).size() > 0) {
        //            $(".indexpage2010_popup", $sender).show();
        //        } else {
        //            $.get("/Ajax/GetCategory.aspx", { "name": $.trim($("a:last", $sender).text()) }, function (result) {
        //                if (result) {
        //                    $sender.prepend(result);
        //                    $(".indexpage2010_popup", $sender).show();
        //                }
        //            }, "html");
        //        }
    }, function () {
        window.hideMenu = setTimeout(function () { $(".indexpage2010_popup:visible").hide(); }, 100);
    });
    $(".indexpage2010_popup").hover(function () {
        $(".Jmenu-list h2 .current").removeClass("current");
        $("h2 a", $(this).parent()).addClass("current");
    }, function () {
        $(".Jmenu-list .current").removeClass("current");
    });

    //下拉
    $(".JDown").hover(function () {
        $(".JContent", this).show();
    }, function () { $(".JContent", this).hide(); });
    //滚动广告
    $(".banner-more-l,.banner-more-r").click(function () {
        var index = $(".banner-more").attr('index');
        if (!index) {
            index = 0;
            $("#banner-more").attr('index', 0);
        } else {
            index = parseInt(index);
        }
        if ($("a", this).hasClass('banner-more-l')) {
            index--;
        } else {
            index++;
        }
        if (index >= $(".banner-more ul").length)
            index = 0;
        if (index < 0)
            index = $(".banner-more ul").length - 1;
        $(".banner-more").attr('index', index);
        $(".banner-more ul:visible").hide();
        $(".banner-more ul").eq(index).show();
        return false;
    });
    //购物车
    $("#i-mycart").hover(
      function () { window.cartWin = setTimeout(function () { $("#o-mycart-list").fadeIn('fast') }, 500); }
    , function () { clearTimeout(cartWin); $("#o-mycart-list").fadeOut('fast'); }
    );
    var cartInfoUrl = "http://order.99read.com/ajax/cartInfo.aspx?jsoncallback=?";
    window.loadCart = function (data) {
        var row = '';
        $(data.Items).each(function (index, item) {
            row = row + '<dl class="index-gouwu-list">'
                        + '<div class="index-gouwu-img"> <img src="' + item.Image + '" width="40" /> </div>'
                        + '<dt><a href="' + item.Url + '">' + item.Name + '</a></dt>'
                        + '<dd>销售价 ：<span class="f-Price">￥' + item.SalePrice + '</span> </dd>'
                        + '<dd> 原价：￥' + item.OriginalPrice + '</dd>'
                        + '<dd> 数量：' + item.Quantity + ' 件</dd>'
                        + '</dl>';
        });
        if (data.Items.length == 0) {
            row = '<span style="margin:10px;color:Gray"><br />您的购物车中暂无商品，赶快选择心爱的商品吧！</span>';
        } else {
            row = row + '<div style="text-align:right; line-height:30px;">共  <span class="f-red" id="itemQuan">'
                + data.Quantity + '</span>  件商品， 金额总计： <span class="f-Price">￥'
                + data.Total + '</span> </div>'
                + '<div style="text-align:right"> <a href="http://order.99read.com"><img src="/images/button/button-JS.jpg" alt="结算中心" border="0" /></a></div>';
        }
        html = row;
        $("#o-mycart-list").html(html);
        $("#mycart-amount").text(data.Quantity);
        $("#goodscount").text('已有' + data.Quantity + '件商品,');
        $(".deleitem").click(function () {
            $(this).text('删除中...');
            $.post($(this).attr('href'), null, function () {
                $.post(cartInfoUrl, null, loadCart, 'html');
            }, 'html');
            return false;
        });
    };
    $.getJSON(cartInfoUrl, null, loadCart);
    //顶部的欢迎信息
    var name = jQuery.cookie("Email");
    var nick = jQuery.cookie("Nick");
    //支付宝金账户
    //var ZFBGodenAccount = jQuery.cookie("ZFBGodenAccount");
    if (nick) {
        name = new Function("return '" + nick + "'")();
    }
    else if (name) {
        var len = name.indexOf('@');
        if (len > 0)
            name = name.substr(0, len);
    }
    if (name) {
        $(".loginInfo").show();
        //        if (ZFBGodenAccount) {
        //            $(".loginInfo .userName").text(name.replace("尊敬的用户", "尊敬的支付宝金账户用户"));
        //        }
        //        else {
        $(".loginInfo .userName").text(name);
        //        }
        $(".welcome").hide();
    }
    $(".loginInfo a,.welcome a,#reviewLogin").each(function () {
        $(this).attr('href', $(this).attr('href') + "?url-redirect-to=" + escape(document.location));
        //if (JudgeSource() == 1 || getCookie("MSC")!="") {
            //var loc = document.location.href.replace("http://", "");
            //if (loc.indexOf("www.99read.com/product") > -1) {
                //$(this).attr('href', $(this).attr('href') + "?url-redirect-to=" + escape(document.location) + "&MSC=BaiduBySearch");
            //}
        //}


    });

    //首页书评
    if ($('#slides').length > 0) {
        $('#slides').slides({
            play: 3500,
            pause: 500,
            hoverPause: true,
            generateNextPrev: false,
            autoHeight: true
        });
    }
});
function isLogin() {
    return false;
}
jQuery.cookie = function (name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        // CAUTION: Needed to parenthesize options.path and options.domain
        // in the following expressions, otherwise they evaluate to undefined
        // in the packed version for some reason...
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};

function JudgeSource() {
    //来源
    var urlstr = document.referrer.replace("http://", "");
    var Soruce = urlstr.substring(0, urlstr.indexOf("/"));
    //来源关键字
    var Args = new Array("baidu.com");
//alert(Soruce);
    for (var i = 0; i < Args.length; i++) {
        if (Soruce.indexOf(Args[i]) > -1)
        { return 1; }
    }
    return 0;
}
//JudgeSource();
var getCookie = function (name) {
        var re = "(?:; )?" + encodeURIComponent(name) + "=([^;]*);?";
        re = new RegExp(re);
        if (re.test(document.cookie)) {
            return decodeURIComponent(RegExp.$1);
        }
        return '';
    };
